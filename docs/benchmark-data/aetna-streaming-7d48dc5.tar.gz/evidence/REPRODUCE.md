# Repeating the Aetna streaming benchmark

This comparison uses the same single-pass Crystal worker for all four builds.
It reads object keys, strings, signed integers, floats, booleans and nulls
using the native streaming pull API, validates the entire document and finishes
at EOF. It retains counters and a deterministic checksum over decoded keys,
strings, numeric values and structure. It uses the common 32 KiB input buffer
and disables key interning. The input is never written out decompressed.

The Dell is an x86-64 Linux host with GNU time, GNU gzip, taskset, Python 3,
Crystal 1.22.3, LLVM 22.1.3, and a 12th-generation Core i9-12900HK. The
scripts use logical CPU 2, check its SMT sibling CPU 3, and read the Dell's
AC power and NVMe telemetry. Adapt these paths to repeat on another host.

From an empty work directory containing the scripts, set the **path only** in
`source.path` to your compressed input. To reproduce the exact source archives:

```sh
git clone https://github.com/wyhaines/fused-json.cr.git fused-source
git clone --depth 1 --branch v0.40.0 https://github.com/sdogruyol/gcry.git gcry-source
git -C fused-source archive --format=tar.gz e06ba59c5c5e402a20425731f4a0acabaa02e3db src > release.tar.gz
git -C fused-source archive --format=tar.gz 7d48dc577e8751bd8690d312a1aa5299c9e586cf src > head.tar.gz
git -C gcry-source archive --prefix=gcry/ --format=tar.gz 0fcca95c6f28a297ae5e633d1ce9fe9d4f41c7e0 src shard.yml > gcry.tar.gz
sh build.sh
taskset -c 0 python3 -B measure.py
python3 summarize.py receipts
```

Both the decompressor and the parser run on CPU 2 in a pipe equivalent to
`gzip -dc -- "$input" | worker`. The controller runs on CPU 0. GNU time
collects per-process CPU and maximum RSS for each side, separately. Pipeline
wall time runs from launch until both processes exit and includes decompression.
The parser CPU column adds its user and system CPU time. The compressed file is
read once for its SHA-256 digest; a separate gzip-to-wc pass counts the exact
64-bit decompressed size and validates the stream. Subsequent timings are
hot-file, fresh-process measurements.

Every measured run must match the baseline's byte count, semantic counters
and checksum and must pass gzip's CRC check. The controller records full
stdout and stderr, status codes, peak RSS in KiB and periodic resident-memory
samples, elapsed time and CPU temperatures. The runs are serial. Two reverse
orders are collected initially. If any same-build wall or parser CPU times
differ by more than 5%, or peak RSS differs by more than 10%, two additional
complete rounds balance the four positions. Deltas pair the two builds within
each round. These observations characterize this input, parser workload, and
CPU budget.

During setup, a preliminary direct-Python launcher included the parent's
high-water mark in `wait4` on this Linux host. Its drain and partial first
parse were excluded before timing the matrix. All reported memory results
use the child of GNU time, with RSS recorded separately for parser and gzip.
