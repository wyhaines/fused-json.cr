"""Render the completed Aetna benchmark report from validated receipts."""
import json,statistics as st,sys
from pathlib import Path

root=Path(sys.argv[1])
summary=json.loads((root/'summary.json').read_text())
env=json.loads((root/'receipts/environment.json').read_text())
extra=json.loads((root/'host-extra.json').read_text())
items=summary["stats"]
def times(m, digits=2):
    return f'{m["median"]:.{digits}f} ({m["min"]:.{digits}f}–{m["max"]:.{digits}f})'
def change(x):
    if abs(x)<0.05: return 'within 0.05% of the release'
    return f'{abs(x):.1f}% '+('lower' if x<0 else 'higher')
out=["# Streaming the Aetna TiC file", "",
     f'On a Dell XPS 15 9520, four optimized Crystal builds streamed the same {summary["plain_bytes"]:,}-byte JSON document from `gzip -dc`. The table gives the median and range across {summary["rounds"]} fresh processes per build. The parser and decompressor shared logical CPU 2, and only one pipeline ran at a time.',"",
     "| fused-json.cr | Collector | Pipeline wall, s (range) | Parser CPU, s (range) | Parser peak RSS, MiB (range) | Input MiB/s |",
     "| --- | --- | ---: | ---: | ---: | ---: |"]
for rev, label in (("release","0.4.0 (`e06ba59`)"),("head","main (`7d48dc5`)")):
    for suffix, collector in (("boehm","Boehm "+extra["boehm_version"]),("gcry","gcry 0.40.0")):
        stats=items[rev+'-'+suffix]
        out.append(f'| {label} | {collector} | {times(stats["wall_s"])} | {times(stats["parser_s"])} | {times(stats["rss_mib"])} | {stats["mib_s"]["median"]:.1f} |')
out+=["","## Comparing the builds","","Percentages use the timing or RSS ratio within each round.",""]
for gc, name in (("boehm","Boehm"),("gcry","gcry")):
    ratios=summary["paired_percent"]["release-"+gc+"/head-"+gc]
    out.append(f'- With {name}, main’s wall time was {change(ratios["wall_s"])} than v0.4.0, parser CPU time was {change(ratios["parser_s"])}, and peak parser RSS was {change(ratios["rss_mib"])}.')
for rev,name in (("release","v0.4.0"),("head","main")):
    ratios=summary["paired_percent"][rev+"-boehm/"+rev+"-gcry"]
    rss_factor=1+ratios["rss_mib"]/100
    out.append(f'- On {name}, gcry used {rss_factor:.2f}× the parser peak RSS of Boehm. Its pipeline wall time was {change(ratios["wall_s"])} and parser CPU time was {change(ratios["parser_s"])}.')
out+=["","## Input and verification","",
      f'The input was `{env["source_file"]}`. Its compressed size was {summary["compressed_bytes"]:,} bytes and its SHA-256 digest was `{env["compressed_sha256"]}`. A separate full pass through `gzip -dc | wc -c` took {summary["drain_wall_s"]:.2f} s and established the decompressed byte count independently.',
      "",f'The worker opens a native FusedJSON pull parser on standard input with a 32 KiB buffer and `cache_keys: false`. It reads each object key and scalar, incorporates the decoded values and container boundaries into a 64-bit checksum, then calls `finish` at EOF. It retains only counters, the current values, and the checksum. Every measured pass produced `{summary["checksum"]}` and counted {summary["common_result"]["negotiated_rate_keys"]:,} `negotiated_rate` keys. Both pipeline processes exited successfully in each run.',
      "","## Timing and memory","",
      f'The runs used Crystal 1.22.3, LLVM 22.1.3, GNU gzip 1.10, Linux {env["kernel"]}, and the Dell\'s {env["governor"]} CPU governor. Each binary used `--release --no-debug --threads 1` at the same build path. The gcry builds also required gcry at startup and used `-Dgc_none`. The baseline linked libgc {extra["boehm_version"]}. The gcry builds identified themselves as 0.40.0. The evidence includes the dynamic-library list for each executable. [gcry integration at v0.40.0](https://github.com/sdogruyol/gcry/blob/v0.40.0/docs/INTEGRATION.md)',
      "",'Pipeline wall time includes decompression, scheduling, checksum work and parsing. Parser CPU adds user and system CPU time for the parser process. GNU time measures each process separately. Peak parser RSS includes the executable, runtime, heap and buffers. Gzip and the OS file cache are outside that figure. Input throughput uses decompressed bytes divided by wall time.',
      "",f'The collector verified AC power, CPU availability and NVMe activity before starting each run. `GC_NPROCS=1` and `GC_MARKERS=1` were set. gcry used its defaults within the single-CPU affinity. Input pages were warmed by a compressed-file checksum and the byte-count pass. The controller collected {summary["rows"]} accepted parser runs and recorded {summary["rejected"]} host-condition retries. The archive includes all observations, individual per-process time and RSS receipts, and the scripts for repeating the measurement. [Raw receipts, worker and reproduction commands](benchmark-data/aetna-streaming-7d48dc5.tar.gz)', ""]
print('\n'.join(out).rstrip())
