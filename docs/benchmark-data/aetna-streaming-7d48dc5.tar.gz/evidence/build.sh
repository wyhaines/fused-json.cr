set -eu
mkdir -p build bin
cp worker.cr build/worker.cr
tar -xzf gcry.tar.gz -C build
for version in release head; do
  tar -xzf "$version.tar.gz" -C build
  (cd build && crystal build --release --no-debug --threads 1 worker.cr -o "../bin/$version-boehm")
  (cd build && crystal build --release --no-debug --threads 1 -Dgc_none worker.cr -o "../bin/$version-gcry")
done
