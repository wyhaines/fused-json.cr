"""Serial stdin streaming benchmark. All data-producing processes run on CPU 2."""
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import struct
import subprocess
import time
import quiet

ROOT = Path(__file__).resolve().parent
FILE = Path((ROOT / "source.path").read_text().strip())
CPU = 2
GC_ENV = {k:v for k,v in os.environ.items() if not k.startswith(("GCRY_", "GC_"))}
GC_ENV.update(GC_NPROCS="1", GC_MARKERS="1", LC_ALL="C")
NAMES = ["release-boehm", "head-boehm", "release-gcry", "head-gcry"]
OUT = ROOT / "receipts"
OUT.mkdir(exist_ok=True)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(2**20), b""):
            h.update(chunk)
    return h.hexdigest()

def dump(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n")
    tmp.replace(path)

def stamp():
    s = FILE.stat()
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns]

def wait_resource(proc):
    _, status, ru = os.wait4(proc.pid, 0)
    end = time.monotonic()
    proc.returncode = os.waitstatus_to_exitcode(status)
    return end, dict(status=proc.returncode, user_s=ru.ru_utime, system_s=ru.ru_stime,
                     cpu_s=ru.ru_utime+ru.ru_stime, peak_rss_kib=ru.ru_maxrss,
                     major_faults=ru.ru_majflt, minor_faults=ru.ru_minflt,
                     voluntary_switches=ru.ru_nvcsw, involuntary_switches=ru.ru_nivcsw)

def timed_child(proc):
    try:
        children=Path(f"/proc/{proc.pid}/task/{proc.pid}/children").read_text().split()
        return int(children[0]) if children else None
    except (OSError, ValueError):
        return None

def resource_record(path, status):
    fields = path.read_text().strip().splitlines()[-1].split()
    rss, user, system, major, minor, voluntary, involuntary, exit_code = fields
    return dict(status=status, user_s=float(user), system_s=float(system), cpu_s=float(user)+float(system),
                peak_rss_kib=int(rss), major_faults=int(major), minor_faults=int(minor),
                voluntary_switches=int(voluntary), involuntary_switches=int(involuntary), time_exit=int(exit_code))

def timed(label, cmd):
    # GNU time forks the measured process from a small native launcher. Linux
    # wait4 on a worker exec'd directly by Python can inherit Python's RSS high-water.
    return ["taskset","-c",str(CPU),"/usr/bin/time","-o",str(OUT/(label+".time")),
            "-f","%M %U %S %F %R %w %c %x","--",*cmd]

def current(pid):
    try:
        lines=Path(f"/proc/{pid}/status").read_text().splitlines()
        return {k:int(v.split()[0]) for line in lines for k,_,v in [line.partition(":")]
                if k in {"VmRSS","VmHWM","VmSwap","Threads"}}
    except (OSError,ValueError):
        return {}

def gzip_offset(pid):
    try:
        for fd in Path(f"/proc/{pid}/fd").iterdir():
            if os.readlink(fd)==str(FILE):
                info=Path(f"/proc/{pid}/fdinfo/{fd.name}").read_text()
                return int(next(x.split()[1] for x in info.splitlines() if x.startswith("pos:")))
    except (OSError,ValueError,StopIteration):
        pass
    return None

def mem_available():
    return int(next(s.split()[1] for s in Path("/proc/meminfo").read_text().splitlines() if s.startswith("MemAvailable:")))

def temperature():
    sensors = []
    for p in Path("/sys/class/thermal").glob("thermal_zone*"):
        if (p/"type").read_text().strip()=="x86_pkg_temp":
            sensors.append(int((p/"temp").read_text())/1000)
    return max(sensors,default=None)

def delta(a,b):
    return [v-w for w,v in zip(a,b)]

def idle(t):
    return (t[3]+t[4])/sum(t) if sum(t) else 0

def pipeline(name, label, original):
    if stamp()!=original: raise RuntimeError("Compressed source changed")
    admission=quiet.admit()
    a=quiet.ticks()
    disk=quiet.disk()
    before=utc()
    start=time.monotonic()
    trace=[]
    cmd=["wc","-c"] if name=="drain" else [str(ROOT/"bin"/name)]
    with (OUT/(label+".out")).open("wb") as stdout, (OUT/(label+".err")).open("wb") as stderr:
        creator=subprocess.Popen(timed(label+"-gzip",["gzip","-dc","--",str(FILE)]), stdout=subprocess.PIPE, stderr=stderr, env=GC_ENV)
        try:
            consumer=subprocess.Popen(timed(label+"-reader",cmd), stdin=creator.stdout, stdout=stdout, stderr=stderr, env=GC_ENV)
        finally:
            creator.stdout.close()
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            gs=pool.submit(wait_resource,creator); ps=pool.submit(wait_resource,consumer)
            while not (gs.done() and ps.done()):
                point=dict(elapsed_s=round(time.monotonic()-start,2), gzip_offset=gzip_offset(timed_child(creator)),
                           memory=current(timed_child(consumer)), available_kib=mem_available(), pkg_c=temperature())
                trace.append(point)
                dump(ROOT/"progress.json",dict(utc=utc(),run=label,point=point))
                if point["available_kib"] < 4*1024*1024:
                    for proc,job in ((creator,gs),(consumer,ps)):
                        if not job.done():
                            try:
                                native=timed_child(proc)
                                if native:os.kill(native,signal.SIGTERM)
                                os.kill(proc.pid,signal.SIGTERM)
                            except ProcessLookupError: pass
                    break
                concurrent.futures.wait([gs,ps],timeout=8)
            gzip_end,gzip_usage=gs.result()
            parser_end,parser_usage=ps.result()
    gzip_usage=resource_record(OUT/(label+"-gzip.time"),gzip_usage["status"])
    parser_usage=resource_record(OUT/(label+"-reader.time"),parser_usage["status"])
    duration=max(gzip_end,parser_end)-start
    b=quiet.ticks()
    host=delta(a["cpu"],b["cpu"]); core=delta(a["cpu2"],b["cpu2"]); sibling=delta(a["cpu3"],b["cpu3"])
    others=[x-y for x,y in zip(host,core)]
    record=dict(label=label, name=name, started=before, ended=utc(), wall_s=duration, parser=parser_usage, gzip=gzip_usage,
                admission=admission, sibling_idle=sibling[3]/sum(sibling), other_available=idle(others),
                disk_busy=max((v-disk[k])/1000/duration for k,v in quiet.disk().items()),
                ac_end=Path("/sys/class/power_supply/AC/online").read_text().strip(), trace=trace)
    raw=(OUT/(label+".out")).read_text().strip()
    if parser_usage["status"]==0 and gzip_usage["status"]==0:
        record["result"]=int(raw) if name=="drain" else json.loads(raw)
    dump(OUT/(label+".json"),record)
    if "result" not in record: raise RuntimeError(f"Pipeline failed: {label} {parser_usage} {gzip_usage}; see stderr")
    if stamp()!=original: raise RuntimeError("Compressed source changed during run")
    print(f'{label} {duration:.2f}s wall, {parser_usage["cpu_s"]:.2f}s consumer CPU, {gzip_usage["cpu_s"]:.2f}s gzip CPU, {parser_usage["peak_rss_kib"]} KiB consumer peak',flush=True)
    return record

def preflight():
    # The four workers must agree with this independently computed fixture oracle.
    sample = '{"é":[null,true,false,-2,3.5,"a\\n"],"negotiated_rate":7}\n'.encode()
    h=0xcbf29ce484222325
    mask=(1<<64)-1
    def mix(v):
        nonlocal h
        h=((h^(v&mask))*0x100000001b3)&mask
    def string(t):
        data=t.encode(); mix(len(data))
        for v in data: mix(v)
    mix(1); string("é"); mix(3); mix(10); mix(8); mix(9); mix(6); mix(-2); mix(7)
    mix(struct.unpack("=Q",struct.pack("=d",3.5))[0]); mix(5); string("a\n"); mix(4)
    string("negotiated_rate"); mix(6); mix(7); mix(2)
    oracle=dict(bytes=len(sample), objects=1,arrays=1,keys=2,strings=1,integers=2,floats=1,literals=3,negotiated_rate_keys=1, checksum=format(h,"x"))
    binaries={}
    for name in NAMES:
        exe=ROOT/"bin"/name
        libs=subprocess.check_output(["ldd",str(exe)],text=True)
        res=json.loads(subprocess.check_output(["taskset","-c",str(CPU),str(exe)],input=sample,env=GC_ENV))
        collector=res.pop("collector")
        if (("libgc.so" in libs)!=(name.endswith("boehm")) or
            collector!=("boehm" if name.endswith("boehm") else "gcry-0.40.0") or res!=oracle):
            raise RuntimeError(f"Preflight mismatch {name}: {res} / {collector}")
        binaries[name]=dict(sha256=sha(exe), linkage=libs, collector=collector)
    return binaries

def main():
    if (OUT/"result.json").exists(): raise FileExistsError("Completed results already exist")
    initial=stamp()
    binaries=preflight()
    settings=dict(source_file=FILE.name, stamp=initial, compressed_sha256=sha(FILE), cpu=CPU, sibling=3, gzip_cpu=CPU,
                  cpu_model=next(s.split(":",1)[1].strip() for s in Path("/proc/cpuinfo").read_text().splitlines() if s.startswith("model name")),
                  machine=Path("/sys/class/dmi/id/product_name").read_text().strip(),kernel=platform.release(),
                  governor=Path("/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor").read_text().strip(),
                  crystal=subprocess.check_output(["crystal","--version"],text=True).strip(),
                  gzip=subprocess.check_output(["gzip","--version"],text=True).splitlines()[0],
                  gc_env={k:v for k,v in GC_ENV.items() if k.startswith(("GCRY_","GC_"))},
                  fused_release="e06ba59c5c5e402a20425731f4a0acabaa02e3db",fused_head="7d48dc577e8751bd8690d312a1aa5299c9e586cf",
                  gcry="0fcca95c6f28a297ae5e633d1ce9fe9d4f41c7e0", artifacts={p:sha(ROOT/p) for p in ["worker.cr","measure.py","build.sh","release.tar.gz","head.tar.gz","gcry.tar.gz"]},
                  binaries=binaries)
    dump(OUT/"environment.json",settings)
    control=pipeline("drain","gzip-drain",initial)
    expected_bytes=control["result"]
    reference=None
    ranked=[["release-boehm","head-gcry","release-gcry","head-boehm"],
            ["head-boehm","release-gcry","head-gcry","release-boehm"],
            ["release-gcry","head-boehm","release-boehm","head-gcry"],
            ["head-gcry","release-boehm","head-boehm","release-gcry"]]
    accepted=[]; retries=[]
    for index,order in enumerate(ranked):
        for name in order:
            for attempt in range(1,4):
                label=f"r{index+1}-{name}-a{attempt}"
                rec=pipeline(name,label,initial); actual=dict(rec["result"])
                collector=actual.pop("collector")
                if actual["bytes"]!=expected_bytes or actual["negotiated_rate_keys"]<=0 or (reference is not None and actual!=reference):
                    raise RuntimeError(f"Dataset result mismatch: {label} {actual} expected {reference} / {expected_bytes}")
                reference=actual
                if rec["sibling_idle"]>=0.95 and rec["other_available"]>=0.90 and rec["ac_end"]=="1":
                    accepted.append(label)
                    break
                retries.append(label)
                print("Host check failed, retaining and retrying "+label,flush=True)
            else: raise RuntimeError("Persistent competing load")
        dump(OUT/"checkpoint.json",dict(accepted=accepted,retries=retries,common_result=reference))
        # Two reverse-order pairs are the initial large-file screen. Extend as
        # a full counterbalanced block if elapsed time or peak memory is noisy.
        if index==1:
            noisy=False
            for name in NAMES:
                a,b=[json.loads((OUT/(k+".json")).read_text()) for k in accepted if k.split("-",1)[1].startswith(name)]
                for x,y,threshold in [(a["wall_s"],b["wall_s"],0.05),(a["parser"]["cpu_s"],b["parser"]["cpu_s"],0.05),
                                        (a["parser"]["peak_rss_kib"],b["parser"]["peak_rss_kib"],0.10)]:
                    if max(x,y)/min(x,y)-1>threshold: noisy=True
            if not noisy: break
            print("Collecting two additional complete rounds under the preset variability rule",flush=True)
    dump(OUT/"result.json",dict(accepted=accepted,retries=retries,common_result=reference,finished=utc()))

if __name__=="__main__": main()
