"""Summarize paired real-file streaming receipts; check all telemetry and input identities."""
import json
import math
import statistics as st
import sys
from pathlib import Path
from collections import defaultdict

root=Path(sys.argv[1])
get=lambda f: json.loads((root/f).read_text())
env=get("environment.json")
finish=get("result.json")
control=get("gzip-drain.json")
expected=finish["common_result"]
assert expected["bytes"]==control["result"]
rows=[]
by_name=defaultdict(list)
for label in finish["accepted"]:
    item=get(label+".json")
    result=dict(item["result"])
    collector=result.pop("collector")
    assert result==expected and env["binaries"][item["name"]]["collector"]==collector
    assert item["parser"]["status"]==item["gzip"]["status"]==0
    assert item["parser"]["time_exit"]==item["gzip"]["time_exit"]==0
    assert item["sibling_idle"]>=0.95 and item["other_available"]>=0.90 and item["ac_end"]=="1"
    assert item["parser"]["peak_rss_kib"]>0
    item["round"]=int(label.split("-")[0][1:])
    item["rss_mib"]=item["parser"]["peak_rss_kib"]/1024
    item["parser_s"]=item["parser"]["cpu_s"]
    item["gzip_s"]=item["gzip"]["cpu_s"]
    item["mib_s"]=expected["bytes"]/2**20/item["wall_s"]
    by_name[item["name"]].append(item)
    rows.append(item)
assert len(by_name)==4 and len({len(g) for g in by_name.values()})==1
deltas={}
for base,cand in (("release-boehm","head-boehm"),("release-gcry","head-gcry"),("release-boehm","release-gcry"),("head-boehm","head-gcry")):
    one={x["round"]:x for x in by_name[base]}
    two={x["round"]:x for x in by_name[cand]}
    assert one.keys()==two.keys() and len(one)==len(by_name[base])
    deltas[base+"/"+cand]={k:st.median(100*(two[r][k]/one[r][k]-1) for r in one) for k in ("wall_s","parser_s","rss_mib")}
stats={}
for name,items in by_name.items():
    stats[name]={}
    for k in ("wall_s","parser_s","gzip_s","rss_mib","mib_s"):
        vals=[it[k] for it in items]
        stats[name][k]=dict(median=st.median(vals),min=min(vals),max=max(vals),samples=vals)
summary=dict(rows=len(rows),rounds=len(rows)//4,compressed_bytes=env["stamp"][2],plain_bytes=expected["bytes"],
             checksum=expected["checksum"],common_result=expected,stats=stats,paired_percent=deltas,
             drain_wall_s=control["wall_s"],drain_gzip_cpu_s=control["gzip"]["cpu_s"],
             rejected=len(finish["retries"]),other_available_min=min(x["other_available"] for x in rows),
             sibling_idle_min=min(x["sibling_idle"] for x in rows),
             gzip_peak_range_mib=[min(x["gzip"]["peak_rss_kib"] for x in rows)/1024,max(x["gzip"]["peak_rss_kib"] for x in rows)/1024])
print(json.dumps(summary,indent=2))
