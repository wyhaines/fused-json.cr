#!/usr/bin/env bash
set -euo pipefail
rev=$1
export GC_MARKERS=1 GC_NPROCS=1 CRYSTAL_WORKERS=1 OMP_NUM_THREADS=1 LC_ALL=C
export FUSED_JSON_BENCH_CPU="$(awk -F': ' '/model name/ {print $2; exit}' /proc/cpuinfo)"
{
  date -u --iso-8601=seconds
  uname -srvmo
  crystal --version
  printf 'runtime commit %s\nCPU %s\n' "$rev" "$FUSED_JSON_BENCH_CPU"
  cat /sys/class/dmi/id/product_name /sys/devices/system/cpu/cpu2/topology/thread_siblings_list /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
  sha256sum bin/tic-bench bin/tic-fixture bin/large-offset
} > receipts/build.txt
python3 -B quiet.py >> receipts/quiet.jsonl
taskset -c 2 bin/large-offset > receipts/large-offset.txt
for size in 268435456 1073741824 4362076160; do
  python3 -B quiet.py >> receipts/quiet.jsonl
  printf 'Generating %s bytes\n' "$size"
  taskset -c 2 bin/tic-fixture --profile many-small --bytes "$size" --seed 7 --field-order providers-first \
    --output "fixtures/$size.json" --manifest "receipts/$size.meta.json" > "receipts/$size.generate.txt"
  test "$(stat -c %s "fixtures/$size.json")" = "$size"
  if [[ "$size" == 268435456 ]]; then
    taskset -c 2 bin/tic-bench verify --input "fixtures/$size.json" --manifest "receipts/$size.meta.json" > receipts/verify-256m.json
    jq -e '.status == "verified" and .typed_verified == true and .raw_number_verified == true' receipts/verify-256m.json >/dev/null
  fi
  for sample in 1 2 3; do
    python3 -B quiet.py >> receipts/quiet.jsonl
    stem="receipts/rss-$size-$sample"
    taskset -c 2 /usr/bin/time -v -o "$stem.time" bin/tic-bench rss --mode fused-typed \
      --input "fixtures/$size.json" --manifest "receipts/$size.meta.json" --commit "$rev" > "$stem.json"
    jq -e --arg rev "$rev" --argjson size "$size" '.command=="rss" and .mode=="fused-typed" and .runtime.fused_json_commit==$rev and .logical_document_bytes==$size and .typed_records>0 and .projection_checksum==.expected_projection_checksum' "$stem.json" >/dev/null
    printf '%s pass %s: ' "$size" "$sample"
    awk '/Maximum resident set size/ {print $NF " KiB"}' "$stem.time"
  done
done
python3 - <<'PY'
from pathlib import Path
import json,re
samples={}
for size in (268435456,1073741824,4362076160):
    samples[str(size)]=[int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',p.read_text()).group(1)) for p in sorted(Path('receipts').glob(f'rss-{size}-*.time'))]
    assert len(samples[str(size)])==3
small=max(samples['268435456']+samples['1073741824'])
ceiling=small+max(16384,small*0.25)
passed=all(x<ceiling for x in samples['4362076160'])
summary=dict(peak_rss_kib=samples,ceiling_kib=ceiling,passed=passed)
Path('receipts/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(summary)
assert passed
PY
