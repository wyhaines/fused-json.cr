# FusedJSON 1.0.0 no-retention measurements

The measured release candidate is `7cbad94ac073e2d301f189997227149533e6e372`.
Its `docs/release-1.0.0.md` records the sizes, repetitions and RSS ceiling
chosen before the run. `dell/` contains every generated fixture manifest,
measurement, GNU-time record, verification result, and the binary hashes.
The payloads can be regenerated from the manifests.

From a clean checkout of that commit, use Crystal 1.22.3 on a quiet
Linux x86-64 host. Run in a new work directory with the two archived
scripts, GNU time, jq and Python 3. Allow at least 6 GiB for the temporary
synthetic inputs. The scripts pin CPU 2 and sample its sibling CPU 3 and
the Dell AC and NVMe interfaces. Adapt those paths for other hardware.

```sh
rev=7cbad94ac073e2d301f189997227149533e6e372
mkdir -p bin fixtures receipts
crystal build --release --no-debug --threads 1 "$repo/bench/tic_fixture.cr" -o bin/tic-fixture
crystal build --release --no-debug --threads 1 "$repo/bench/tic.cr" -o bin/tic-bench
crystal build --release --no-debug --threads 1 "$repo/scripts/check_large_offset.cr" -o bin/large-offset
bash release-rss.sh "$rev"
```

Set `repo` to the checkout path. Use `sha256sum -c SHA256SUMS` in the
extracted evidence directory to verify the archived files.
