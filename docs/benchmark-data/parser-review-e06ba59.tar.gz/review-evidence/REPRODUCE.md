# Repeating the parser review benchmark

The parent revision is `e06ba59c5c5e402a20425731f4a0acabaa02e3db`. The
runtime patch contains the complete changes under `src/` used by the measured
candidate. The source digests use the repository's compile-time identity
format: sorted relative paths, a colon, each file's SHA-256 digest, and LF.
The observation files also record the SHA-256 digests of both executables.

Use a quiet x86-64 Linux machine on AC power with NVMe, a performance core
on logical CPU 2 and its SMT sibling on CPU 3. The runner uses those two CPU
numbers and the Linux AC and block-device interfaces directly. The measured
machine was a Dell XPS 15 9520, Intel Core i9-12900HK, Crystal 1.22.3 and LLVM
22.1.3. Both executables were built from the same absolute source directory
with the same command and default target.

From the extracted evidence directory, with a clean folder for a new checkout:

```sh
evidence=$PWD
git clone https://github.com/wyhaines/fused-json.cr.git work
cd work
git checkout --detach e06ba59c5c5e402a20425731f4a0acabaa02e3db
cp "$evidence"/review_bench.cr "$evidence"/quiet.py "$evidence"/pairs.py .
crystal build --release --no-debug --threads 1 review_bench.cr -o baseline
git apply "$evidence/runtime-final.patch"
crystal build --release --no-debug --threads 1 review_bench.cr -o candidate
python3 -B pairs.py string-int64 gap-int64 gap-int32 io-int32 end-location string-keys stream-keys plain-keys standard-tree
python3 "$evidence/compare_summary.py" pairs.json
```

Each check compares complete calls to public parsing methods. String and IO
array profiles sum the integers 1 through 2048. The gap profiles skip a
32 KiB string and read the integer that follows. The location profile reads
2,048 empty objects through a typed constructor that queries its ending
column. The key profiles enable caching and parse 512 distinct keys,
each consisting of a field number and a 192-byte suffix. Escaped and plain
keys decode to the same text. The standard tree control loads the same
integer array through the default String API. Every timed operation verifies
its expected result. The key profiles also compare the full tree to Crystal's
stdlib before timing.

Each of the six rounds uses one fresh process per workload and binary, with
alternating pair order. Each process calibrates a batch, warms up for at least
one second and measures for at least one second. The collector saves all batch
rates, managed bytes allocated per operation, process order and host checks.
It calculates the median of the six baseline/candidate time ratios.
`GC_NPROCS=1` and `GC_MARKERS=1` are set for each worker. The host's
governor and power profile were left as found.

`final.json` contains the reported run. `first-implementation.json` records
the initial implementation, which slowed streaming Int32 reads. To reproduce
that candidate, apply `final-to-first.patch` on top of `runtime-final.patch`.
`interrupted-metric.json` is a partial earlier run whose benchmark overflowed
while reporting throughput. The complete campaigns convert bytes to Float64
before multiplying by iteration count.
