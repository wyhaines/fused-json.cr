require "./src/fused_json"

struct LocatedValue
  getter column : Int64

  def initialize(pull : JSON::PullParser)
    pull.skip
    @column = pull.location_i64[1]
  end
end

def int_operation(pull, skipped, type : T.class) forall T
  total = 0_i64
  if skipped
    pull.read_begin_array
    pull.skip
    total = pull.read(T).to_i64
    pull.read_end_array
  else
    pull.read_array(T) { |n| total += n }
  end
  pull.finish
  total
end

def operation(source, profile)
  case profile
  when "string-int64", "gap-int64"
    int_operation(FusedJSON::PullParser.new(source), profile.starts_with?("gap"), Int64)
  when "string-int32", "gap-int32"
    int_operation(FusedJSON::PullParser.new(source), profile.starts_with?("gap"), Int32)
  when "io-int32"
    int_operation(FusedJSON::PullParser.new(IO::Memory.new(source)), false, Int32)
  when "end-location"
    pull = FusedJSON::PullParser.new(source)
    total = 0_i64
    pull.read_array(LocatedValue) { |v| total += v.column }
    pull.finish
    total
  when "standard-tree"
    FusedJSON.load(source).as_a.sum(&.as_i64)
  else
    tree = if profile.starts_with?("stream")
             FusedJSON.load(IO::Memory.new(source), cache_keys: true)
           else
             FusedJSON.load(source, cache_keys: true)
           end
    tree.as_h.sum { |key, v| key.bytesize.to_i64 + v.as_i64 }
  end
end

profile = ARGV.first
source, expected = if profile.starts_with?("gap")
                     {"[\"#{"abcd" * 8192}\",1234]", 1234_i64}
                   elsif profile == "end-location"
                     n = 2048_i64
                     {"[" + (["{}"] * n.to_i32).join(",") + "]", (3*n*(n+1))//2 + 2*n - 1}
                   elsif profile.ends_with?("keys")
                     suffix = "sensor" * 32
                     text = String.build do |io|
                       io << '{'
                       512.times do |i|
                         io << ',' unless i.zero?
                         io << "\"field" << i << (profile.starts_with?("plain") ? "-" : "\\u002d") << suffix << "\":" << i
                       end
                       io << '}'
                     end
                     reference = JSON.parse(text)
                     actual = FusedJSON.load(text, cache_keys: true)
                     raise "tree mismatch" unless actual == reference && FusedJSON.load(IO::Memory.new(text), cache_keys: true) == reference
                     {text, reference.as_h.sum { |key, v| key.bytesize.to_i64 + v.as_i64 }}
                   else
                     values = (1..2048).to_a
                     {values.to_json, values.sum(&.to_i64)}
                   end
raise "preflight" unless operation(source, profile) == expected
count = 1
while true
  start = Time.instant
  count.times { raise "wrong checksum" unless operation(source, profile) == expected }
  seconds = (Time.instant - start).total_seconds
  break if seconds >= 0.04
  count *= 2
end
["warmup", "sample"].each do |phase|
  iterations = 0_i64
  stats = [] of Float64
  elapsed = 0.0
  allocated = 0_u64
  while elapsed < 1.0
    before = GC.stats.total_bytes
    start = Time.instant
    count.times { raise "wrong checksum" unless operation(source, profile) == expected }
    seconds = (Time.instant - start).total_seconds
    allocated += GC.stats.total_bytes - before
    iterations += count
    elapsed += seconds
    stats << count / seconds
  end
  if phase == "sample"
    puts({profile: profile, bytes: source.bytesize, iterations: iterations, seconds: elapsed, bytes_per_op: allocated / iterations, samples: stats, us: elapsed * 1e6 / iterations, mib_s: source.bytesize.to_f64 * iterations / elapsed / 1048576.0}.to_json)
  end
end
