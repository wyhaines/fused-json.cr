import json,sys,statistics
from pathlib import Path
path=Path(sys.argv[1])
r=json.loads(path.read_text())
groups={}
for sample in r["observations"]:
   groups.setdefault(sample["profile"],{}).setdefault(sample["round"],{})[sample["worker"]]=sample
for name,pairs in groups.items():
    if any(len(group)!=2 for group in pairs.values()):continue
    b=[g["baseline"] for g in pairs.values()]
    c=[g["candidate"] for g in pairs.values()]
    ratios=[x["us"]/y["us"] for x,y in zip(b,c)]
    def med(v,k):return statistics.median(i[k] for i in v)
    print(f'{name:15} n={len(pairs):2}  {med(b,"us"):9.2f} {med(c,"us"):9.2f}  {statistics.median(ratios):7.3f}x [{min(ratios):.3f},{max(ratios):.3f}]  {med(b,"bytes_per_op"):.0f}/{med(c,"bytes_per_op"):.0f}')
