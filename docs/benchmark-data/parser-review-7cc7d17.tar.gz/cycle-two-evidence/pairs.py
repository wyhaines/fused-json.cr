from pathlib import Path
import subprocess,statistics,hashlib,json,datetime,sys,os, time
import quiet
profiles=sys.argv[1:]
env=dict(os.environ,GC_MARKERS="1",GC_NPROCS="1")
state=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),build_dir=os.getcwd(),
    hashes={b:hashlib.sha256(Path(b).read_bytes()).hexdigest() for b in ("baseline","candidate","review_bench.cr")},
    crystal=subprocess.check_output(["crystal","--version"],text=True).strip(),
    core=2,sibling=3,power_profile=Path("/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor").read_text().strip(),
    observations=[],retries=[],quiet=[])
def save():
    p=Path("pairs.tmp"); p.write_text(json.dumps(state,indent=2)+"\n"); p.replace("pairs.json")
for r in range(6):
    state["quiet"].append(quiet.admit())
    for k in range(len(profiles)):
        ix=(r+k)%len(profiles)
        name=profiles[ix]
        order=("baseline","candidate") if (ix+r)%2==0 else ("candidate","baseline")
        for worker in order:
            for attempt in range(3):
                a,d=quiet.ticks(),quiet.disk()
                start=time.monotonic()
                cmd=["taskset","-c","2","./"+worker,name]
                item=json.loads(subprocess.check_output(cmd,env=env,text=True,timeout=90))
                b=quiet.ticks()
                elapsed=time.monotonic()-start
                delta=[y-x for x,y in zip(a["cpu3"],b["cpu3"])]
                item.update(round=r+1,worker=worker,sibling_idle=delta[3]/sum(delta),ac=Path("/sys/class/power_supply/AC/online").read_text().strip(),
                    disk_busy=max((v-d[key])/1000/elapsed for key,v in quiet.disk().items()))
                total=[y-x for x,y in zip(a['cpu'],b['cpu'])]
                item['host_available']=(total[3]+total[4])/sum(total)
                if item['sibling_idle']>=0.95 and item['disk_busy']<=0.10 and item['host_available']>=0.90 and item['ac']=='1':
                    state['observations'].append(item);save();break
                state['retries'].append(item);save()
                state['quiet'].append(quiet.admit())
            else:raise RuntimeError("Could not obtain quiet sample")
    print("Round",r+1,flush=True)
for name in profiles:
    groups=[[s for s in state["observations"] if s["profile"]==name and s["worker"]==w] for w in ("baseline","candidate")]
    ratios=[x["us"]/y["us"] for x,y in zip(*groups)]
    print(name, "median paired speedup", round(statistics.median(ratios),3), "range", round(min(ratios),3),round(max(ratios),3), "bytes/op", *[round(statistics.median(x["bytes_per_op"] for x in g)) for g in groups],flush=True)
