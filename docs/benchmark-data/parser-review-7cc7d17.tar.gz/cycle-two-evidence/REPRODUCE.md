# Reproduce the second parser review

The Dell run used a Core i9-12900HK on AC power, Crystal 1.22.3, LLVM 22.1.3,
taskset, and Python 3. CPU 2 has CPU 3 as its SMT sibling. The runner samples
those CPUs, the AC supply and NVMe activity directly. Use the same host, or
adjust the topology and power paths in the scripts to match your Linux host.

From this extracted directory, choose an empty directory for the checkout:

```sh
evidence=$PWD
git clone https://github.com/wyhaines/fused-json.cr.git work
cd work
git checkout --detach 7cc7d17f7f9a050a8f7b0dfb926f1942bb054b39
cp "$evidence"/review_bench.cr "$evidence"/pairs.py "$evidence"/quiet.py .
crystal build --release --no-debug --threads 1 review_bench.cr -o baseline
git apply "$evidence/runtime.patch"
crystal build --release --no-debug --threads 1 review_bench.cr -o candidate
python3 -B pairs.py capped-objects capped-ints reject-duplicates select-key skip-string typed-hash objects ints stream-escaped
python3 "$evidence/compare_summary.py" pairs.json
```

The collector alternates baseline and candidate order across six pairs per
profile and launches a fresh process each time. The worker checks expected
results, warms up for at least one second, and takes at least one second of
timings in batches. The rates and managed allocation counts are per complete
public operation. Both binaries were compiled with the same source paths and
flags. For select-key, the worker uses the new key-only method when available
and the existing key iteration method on the baseline.

`final.json` contains the build path, compiler identity, worker and executable
hashes, warm host admission checks, individual timing samples and any retries.
`source-digests.json` hashes the baseline and candidate runtime files under
`src/` in the format used by `bench/runtime_source_identity.cr`.
