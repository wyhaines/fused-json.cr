require "./src/fused_json"

profile = ARGV.first
source = case profile
         when "capped-objects", "objects", "reject-duplicates"
           Array.new(1024) { |i| {"a" => i, "b" => i % 7} }.to_json
         when "select-key"
           %({"padding":"#{"x" * 65536}","id":17})
         when "skip-string"
           %([["#{"a" * 1048576}"],7])
         when "stream-escaped"
           Array.new(256) { "line\n" * 16 }.to_json
         when "typed-hash"
           (0...1024).to_h { |i| {"key#{i}", i} }.to_json
         else
           Array.new(4096) { |i| i }.to_json
         end
limits = FusedJSON::Limits.new(max_document_bytes: profile.starts_with?("capped") ? source.bytesize : nil,
  reject_duplicate_keys: profile == "reject-duplicates")
oracle = JSON.parse(source)
raise "oracle" unless FusedJSON.load(source, limits: limits) == oracle
operation, expected = case profile
                      when "select-key"
                        op = -> do
                          pull = FusedJSON::PullParser.new(source)
                          value = 0
                          if pull.responds_to?(:read_object_keys)
                            pull.read_object_keys { |k| k == "id" ? (value = pull.read_int.to_i) : pull.skip }
                          else
                            pull.read_object { |k| k == "id" ? (value = pull.read_int.to_i) : pull.skip }
                          end
                          pull.finish
                          value
                        end
                        {op, oracle["id"].as_i}
                      when "skip-string"
                        op = -> do
                          pull = FusedJSON::PullParser.new(IO::Memory.new(source))
                          pull.read_begin_array
                          pull.skip
                          value = pull.read_int
                          pull.read_end_array
                          pull.finish
                          value.to_i
                        end
                        {op, oracle[1].as_i}
                      when "typed-hash"
                        op = -> { FusedJSON.from_json(source, Hash(String, Int32)).size }
                        {op, oracle.as_h.size}
                      when "stream-escaped"
                        op = -> { FusedJSON.load(IO::Memory.new(source)).as_a.size }
                        {op, oracle.as_a.size}
                      else
                        op = -> { FusedJSON.load(source, limits: limits).as_a.size }
                        {op, oracle.as_a.size}
                      end
raise "preflight" unless operation.call == expected
count = 1
while true
  start = Time.instant
  count.times { raise "wrong checksum" unless operation.call == expected }
  seconds = (Time.instant - start).total_seconds
  break if seconds >= 0.04
  count *= 2
end
["warmup", "sample"].each do |phase|
  iterations = 0_i64
  stats = [] of Float64
  elapsed = 0.0
  allocated = 0_u64
  while elapsed < 1.0
    before = GC.stats.total_bytes
    start = Time.instant
    count.times { raise "wrong checksum" unless operation.call == expected }
    seconds = (Time.instant - start).total_seconds
    allocated += GC.stats.total_bytes - before
    iterations += count
    elapsed += seconds
    stats << count / seconds
  end
  if phase == "sample"
    puts({profile: profile, bytes: source.bytesize, iterations: iterations, seconds: elapsed, bytes_per_op: allocated / iterations, samples: stats, us: elapsed * 1e6 / iterations, mib_s: source.bytesize.to_f64 * iterations / elapsed / 1048576.0}.to_json)
  end
end
