#!/usr/bin/env bash
set -eu
cd "$1"
src="${HOLDOUT_SOURCE:-/home/wyhaines/sunlight-dell/valley/carrier-raw-20261112/uhc/2026-11-01_UMR--Inc-_Third-Party-Administrator_MONUMENT-HEALTH-UHC-CSP_WEST-VIRGINIA-CCP-WEST-VIRGINIA-UNIVERSITY_-GUM_PEDW_in-network-rates.json.gz}"
python3 -B quiet.py
taskset -c 2 gzip -dc -- "$src" | taskset -c 2 ./prefix 1073741824 | taskset -c 2 gzip -1c > uhc-prefix.gz
rc=("${PIPESTATUS[@]}")
[[ ("${rc[0]}" == 141 || "${rc[0]}" == 0) && "${rc[1]}" == 0 && "${rc[2]}" == 0 ]]
printf '%s\n' "$src" > holdout-source.path
taskset -c 0 python3 -B holdout.py
