from pathlib import Path
import bisect,collections,os,subprocess
maps=[]; bases={}
for line in Path('profile.maps').read_text().splitlines():
    v=line.split(maxsplit=5)
    if len(v)==6 and int(v[2],16)==0: bases[v[5]]=int(v[0].split('-')[0],16)
    if 'x' not in v[1] or len(v)!=6 or not v[5].startswith('/'):continue
    a,b=[int(t,16) for t in v[0].split('-')]
    maps.append((a,b,int(v[2],16),v[5]))
pcs=[int(p,16) for p in Path('profile.ips').read_text().splitlines()]
groups=collections.Counter(); details=collections.Counter(); symbols={}
for ip in pcs:
    for a,b,offset,path in maps:
        if not a<=ip<b:continue
        if path not in symbols:
            elf=subprocess.check_output(['readelf','-h',path],text=True)
            pie='DYN' in next(x for x in elf.splitlines() if 'Type:' in x)
            items={}
            for flag in ([],['-D']):
                p=subprocess.run(['nm','-n',*flag,path],capture_output=True,text=True)
                for line in p.stdout.splitlines():
                    s=line.split(maxsplit=2)
                    if len(s)==3 and s[1] in 'tTwW':
                        try:items[int(s[0],16)]=s[2]
                        except ValueError:pass
            symbols[path]=(sorted(items),items,pie)
        keys,entries,pie=symbols[path]; addr=ip-bases[path] if pie else ip
        i=bisect.bisect_right(keys,addr)-1
        func=entries[keys[i]] if i>=0 else '?'
        groups[Path(path).name,func]+=1
        if 'symbolized' in path: details[addr]+=1
        break
print('PC samples:',len(pcs))
for (module,f),count in groups.most_common(28):
    print('%5.1f%% %-16s %s'%(100*count/len(pcs),module,f))
if details:
    addrs=list(details)
    lines=subprocess.check_output(['addr2line','-e','bin/symbolized',*[hex(x) for x in addrs]],text=True).splitlines()
    byline=collections.Counter()
    for addr,line in zip(addrs,lines):
        byline[line.split(' (')[0]]+=details[addr]
    print('Debug source lines:')
    for line,count in byline.most_common(28):print('%5.1f%% %s'%(100*count/len(pcs),line))
