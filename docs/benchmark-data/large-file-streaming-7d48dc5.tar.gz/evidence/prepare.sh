set -eu
mkdir -p build bin
cp worker.cr build/
tar -xzf head.tar.gz -C build
tar -xzf gcry.tar.gz -C build
python3 -B quiet.py
gcc -O2 prefix.c -o prefix
gcc -O2 -fPIC -shared profile.c -o profile.so
(cd build && crystal build --release --no-debug --threads 1 worker.cr -o ../bin/base && crystal build --release --threads 1 worker.cr -o ../bin/symbolized)
src=$(cat source.path)
taskset -c 2 gzip -dc -- "$src" | taskset -c 2 ./prefix 402653184 | taskset -c 2 gzip -1c > prefix.gz
test -s prefix.gz
taskset -c 2 gzip -dc -- prefix.gz | taskset -c 2 env GC_NPROCS=1 GC_MARKERS=1 LD_PRELOAD="$PWD/profile.so" ./bin/symbolized > profile.result
