import json
from pathlib import Path
import measure as m

m.FILE=(m.ROOT/'uhc-prefix.gz').resolve()
m.OUT=m.ROOT/'holdout-receipts'; m.OUT.mkdir(exist_ok=True)
source=Path((m.ROOT/'holdout-source.path').read_text().strip())
sig=m.stamp()
m.dump(m.OUT/'input.json',dict(source=source.name,source_compressed_bytes=source.stat().st_size,
    extracted_prefix_min=2**30,compressed_sample_bytes=sig[2],compressed_sample_sha256=m.sha(m.FILE),
    worker_binaries={n:m.sha(m.ROOT/'bin'/n) for n in m.NAMES}))
drain=m.pipeline('drain','gzip-drain',sig)
accepted=[]; retries=[]; expected=None
order=['release-boehm','head-boehm','candidate-boehm','candidate-gcry','head-gcry','release-gcry']
for rnd,order in enumerate([order,list(reversed(order))],1):
    for name in order:
        for attempt in range(1,4):
            label=f'r{rnd}-{name}-a{attempt}'
            rec=m.pipeline(name,label,sig)
            check=dict(rec['result'])
            assert check.pop('collector')==('boehm' if name.endswith('boehm') else 'gcry-0.40.0')
            assert check['bytes']==drain['result'] and (expected is None or check==expected)
            expected=check
            if rec['sibling_idle']>=0.95 and rec['other_available']>=0.90 and rec['ac_end']=='1':
                accepted.append(label)
                break
            retries.append(label)
        else:raise RuntimeError('No quiet sample')
    m.dump(m.OUT/'checkpoint.json',dict(accepted=accepted,retries=retries,common_result=expected))
m.dump(m.OUT/'result.json',dict(accepted=accepted,retries=retries,common_result=expected))
