require "./src/fused_json"
require "digest/sha256"

def inspect_source(source, size, limits, mode)
  io = IO::Memory.new(source)
  case mode
  when :tree
    JSON.build do |json|
      json.max_nesting = 1024
      FusedJSON.load(io, buffer_size: size, limits: limits).to_json(json)
    end
  when :skip
    pull = FusedJSON::PullParser.new(io, buffer_size: size, limits: limits)
    pull.skip
    pull.finish
    {pull.kind.to_s, pull.byte_offset, pull.location_i64}.to_json
  else
    pull = FusedJSON::PullParser.new(io, buffer_size: size, limits: limits)
    JSON.build do |json|
      json.array do
        loop do
          json.array do
            json.string(pull.kind.to_s)
            json.number(pull.byte_offset)
            pull.location_i64.to_json(json)
            case pull.kind
            when .string? then json.string(pull.string_value)
            when .int?, .float? then json.string(pull.raw_number_value)
            when .bool? then json.bool(pull.bool_value)
            end
          end
          break if pull.kind.eof?
          pull.read_next
        end
      end
      pull.finish
    end
  end
rescue e : FusedJSON::ParseError
  {e.class.name, e.byte_offset, e.location_i64, e.message}.to_json
end

Dir["spec/fixtures/json_test_suite/test_parsing/*.json"].sort.each do |path|
  source=File.read(path)
  {1, 7, 32, 32*1024}.each do |size|
    {FusedJSON::Limits::DEFAULT, FusedJSON::Limits.new(max_token_bytes: 17, max_document_bytes: 257, reject_duplicate_keys: true)}.each_with_index do |limits,i|
      {:tree,:skip,:events}.each do |mode|
        result=inspect_source(source,size,limits,mode)
        puts "#{File.basename(path)} #{size} #{i} #{mode} #{Digest::SHA256.hexdigest(result)}"
      end
    end
  end
end
