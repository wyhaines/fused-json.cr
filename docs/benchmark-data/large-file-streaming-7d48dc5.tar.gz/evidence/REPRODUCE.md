# Reproduce the large-file streaming measurements

The full-file test uses the same worker as the original Aetna comparison. Each
run consumes one complete gzip stream. The program reads every object key and
scalar with FusedJSON's native pull operations, accumulates counters and a
64-bit checksum, and checks EOF. It holds no result tree. The exact same
worker source is compiled for all six binaries.

## Build

Use Linux x86-64 with Crystal 1.22.3 and LLVM 22.1.3 to match the Dell run.
Use a fresh work directory with the scripts and candidate patch from this
archive. Git and GNU tar are needed to make the source archives.

```sh
git clone https://github.com/wyhaines/fused-json.cr.git fused-source
git clone --depth 1 --branch v0.40.0 https://github.com/sdogruyol/gcry.git gcry-source
base=7d48dc577e8751bd8690d312a1aa5299c9e586cf
release=e06ba59c5c5e402a20425731f4a0acabaa02e3db
git -C fused-source archive --format=tar.gz "$base" src > head.tar.gz
git -C fused-source archive --format=tar.gz "$release" src > release.tar.gz
git -C gcry-source archive --prefix=gcry/ --format=tar.gz HEAD src shard.yml > gcry.tar.gz
mkdir patched
tar -xzf head.tar.gz -C patched
(cd patched && git apply ../candidate.patch)
tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner -C patched -czf candidate.tar.gz src
sh build_full.sh
```

The patch is against main at the commit above. `candidate-source.sha256`
identifies the patched runtime. The digest hashes the concatenation of the
relative source path, a colon, the file's SHA-256 digest and LF, sorted by
path (each file under `src/` ending in `.cr`). All builds use the same
absolute source directory and compiler options, plus `-Dgc_none` and a
require of gcry for the gcry builds.

## Stream the inputs

Create `source.path` with the path of the original Aetna gzip on a single
line. Use a quiet, AC-powered host. The scripts monitor CPU 2, its SMT sibling
CPU 3, the AC supply, and NVMe devices on the Dell XPS 15 9520. Change those
paths and CPU numbers to repeat on a different host. GNU time, taskset, gzip,
GCC and Python 3 are used.

```sh
taskset -c 0 python3 -B measure.py
python3 summarize.py receipts
gcc -O2 prefix.c -o prefix
HOLDOUT_SOURCE=/path/to/uhc.json.gz bash holdout.sh "$PWD"
python3 summarize.py holdout-receipts
```

The real-file campaign runs two reverse-order rounds. Each gzip/reader pair
shares CPU 2 and is timed as a pipeline, with separate GNU time receipts for
the parser and decompressor. Counts, checksum, decompressed byte count,
collector linkage, and both process exit codes are checked. Preflight uses
a small independently calculated oracle. The gzip-only control establishes
the exact decompressed size via wc. The compressed file is hashed before
timing. Both passes use a warm file cache and fresh processes.

The UHC extractor copies bytes until a structural comma past the target
uncompressed size, emits the matching closing brackets/braces and compresses
the result through a pipe. Only the small synthetic ending changes the
original prefix. A full traversal through EOF checks the resulting document.
Only compressed input and compressed sample files are stored.

## Profile, screening and controls

`prepare.sh` builds a 384 MiB Aetna prefix and samples instruction pointers
from the current main worker with SIGPROF on Linux x86-64. Run it before
`build_full.sh` in a dedicated directory. `profile_report.py` uses ELF maps,
nm, and addr2line to symbolize those samples. Source lines in inlined code
can belong to a caller or to the standard library. Profiling is separate from
all timed runs; the timed binaries are ordinary release binaries.

The screening patches are each relative to the same baseline. The candidates
named copy, contiguous, cursor and punct respectively add a direct owned
string copy, a contiguous ASCII scan and first-element array state update,
buffer-relative byte/column accounting, and the whitespace/punctuation/frame
changes. Punct is the final candidate. Compile each from the same path using
`crystal build --release --no-debug --threads 1 worker.cr` with the appropriate
output binary name. `screen.py` checks the prefix checksum before retaining
measurements.

For the smaller controls, both sides use the committed token harness and the
same build path. Rebuild it as follows in the work directory above:

```sh
git -C fused-source archive --format=tar.gz "$base" bench/streaming_token_cost.cr bench/streaming_token_support.cr bench/runtime_source_identity.cr > guard-harness.tar.gz
sh queue_guards.sh "$PWD"
```

This starts after the holdout receipts are complete. Results include all
individual benchmark receipts, RSD, allocation traffic, and source identities.
The correctness audit can be rerun by copying `audit.cr` to clean baseline
and candidate checkouts, running it from the repository root against the
bundled JSONTestSuite fixtures, and comparing its output byte-for-byte.
