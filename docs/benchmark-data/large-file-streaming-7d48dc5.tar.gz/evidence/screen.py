import os,subprocess,json,time,sys,statistics
from pathlib import Path
from quiet import admit

log=Path(sys.argv[1]); names=sys.argv[2:]
res=[]
for order in (names,list(reversed(names)),names):
    admit()
    for name in order:
        stem='scr-'+name
        start=time.monotonic()
        with subprocess.Popen(['taskset','-c','2','gzip','-dc','--','prefix.gz'],stdout=subprocess.PIPE) as gz:
            cmd=['taskset','-c','2','/usr/bin/time','-o',stem+'.time','-f','%U %S %M','--','bin/'+name]
            proc=subprocess.Popen(cmd,stdin=gz.stdout,stdout=subprocess.PIPE,env=dict(os.environ,GC_MARKERS='1',GC_NPROCS='1'))
            gz.stdout.close()
            out=json.loads(proc.communicate()[0]); assert proc.returncode==0 and gz.wait()==0
        t=time.monotonic()-start
        expected=json.loads(Path('profile.result').read_text())
        assert out==expected,(name,out,expected)
        u,s,r=Path(stem+'.time').read_text().split()
        res.append(dict(name=name,wall=t,cpu=float(u)+float(s),rss=int(r),checksum=out['checksum']))
        log.write_text(json.dumps(res,indent=2)+'\n')
        print(name, round(t,3), round(float(u)+float(s),3), r, flush=True)
for name in names:
    print(name,'median CPU',statistics.median(x['cpu'] for x in res if x['name']==name),flush=True)
