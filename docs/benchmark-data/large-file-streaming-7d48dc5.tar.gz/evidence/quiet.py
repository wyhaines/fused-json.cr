from pathlib import Path
import time,os,json
def ticks():
    return {p[0]:list(map(int,p[1:9])) for l in Path('/proc/stat').read_text().splitlines() if (p:=l.split()) and p[0] in ('cpu','cpu2','cpu3')}
def disk():
    return {f:int((f/'stat').read_text().split()[9]) for f in Path('/sys/block').glob('nvme*n*')}
def sample():
    a,d=ticks(),disk()
    start=time.monotonic()
    time.sleep(2)
    elapsed=time.monotonic()-start
    b=ticks()
    def idle(cpu,include_wait=False):
        delta=[y-x for x,y in zip(a[cpu],b[cpu])]
        return (delta[3]+(delta[4] if include_wait else 0))/sum(delta)
    return dict(idle=idle('cpu',True), core=idle('cpu2'), sibling=idle('cpu3'),disk=max((t-d[k])/1000/elapsed for k,t in disk().items()),ac=Path('/sys/class/power_supply/AC/online').read_text().strip(),load=os.getloadavg())
def admit():
    for _ in range(24):
        s=sample()
        if min(s['idle'],s['core'],s['sibling'])>=0.95 and s['disk']<=0.1 and s['ac']=='1': return s
        time.sleep(3)
    raise RuntimeError("no quiet window")
if __name__=='__main__': print(json.dumps(admit()))
