#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
/* Copy a prefix of a valid JSON input and close its containers immediately
 * before the first separator at or past the requested offset. */
int main(int argc, char **argv) {
  if (argc != 2) return 2;
  uint64_t target = strtoull(argv[1], NULL, 10), total = 0;
  char closers[512]; unsigned depth = 0; int in_string = 0, escaped = 0;
  unsigned char buf[65536]; size_t n;
  while ((n = fread(buf, 1, sizeof(buf), stdin))) {
    for (size_t i=0; i<n; i++) {
      unsigned char c = buf[i];
      if(in_string) {if(escaped) escaped=0; else if(c=='\\') escaped=1; else if(c=='"') in_string=0; continue;}
      if(c=='"') in_string=1;
      else if(c=='[' || c=='{') {if(depth==512) return 3; closers[depth++]=c=='[' ? ']' : '}';}
      else if(c==']' || c=='}') {if(!depth || closers[--depth]!=c) return 4;}
      else if(c==',' && total+i>=target) {
        if(fwrite(buf,1,i,stdout)!=i) return 5;
        while(depth) if(putchar(closers[--depth])==EOF) return 5;
        return fflush(stdout)!=0;
      }
    }
    if(fwrite(buf,1,n,stdout)!=n) return 5;
    total+=n;
  }
  return ferror(stdin) || fflush(stdout)!=0;
}
