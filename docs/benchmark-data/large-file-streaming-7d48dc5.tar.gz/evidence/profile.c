#define _GNU_SOURCE
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/time.h>
#include <ucontext.h>
#include <unistd.h>
static uintptr_t pcs[250000];
static volatile sig_atomic_t count;
static void capture(int sig, siginfo_t *info, void *context) {
  if(count < (sig_atomic_t)(sizeof(pcs)/sizeof(*pcs)))
    pcs[count++] = (uintptr_t)((ucontext_t*)context)->uc_mcontext.gregs[REG_RIP];
}
__attribute__((constructor)) static void start(void) {
  FILE *in=fopen("/proc/self/maps","r"), *out=fopen("profile.maps","w");
  char buf[4096];
  if(in && out) while(fgets(buf,sizeof(buf),in)) fputs(buf,out);
  if(in) fclose(in); if(out) fclose(out);
  struct sigaction sa={0}; sa.sa_sigaction=capture; sa.sa_flags=SA_SIGINFO|SA_RESTART;
  sigemptyset(&sa.sa_mask); sigaction(SIGPROF,&sa,0);
  struct itimerval tv={{0,1000},{0,1000}}; setitimer(ITIMER_PROF,&tv,0);
}
__attribute__((destructor)) static void finish(void) {
  struct itimerval tv={{0,0},{0,0}}; setitimer(ITIMER_PROF,&tv,0);
  FILE *f=fopen("profile.ips","w"); if(!f)return;
  for(int i=0;i<count;i++) fprintf(f,"%lx\n",(unsigned long)pcs[i]);
  fclose(f);
}
