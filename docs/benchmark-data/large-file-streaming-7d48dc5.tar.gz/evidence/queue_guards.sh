set -eu
cd "$1"
while ! test -s holdout-receipts/result.json; do sleep 10; done
mkdir -p guards/build
cp quiet.py guard_dell.py guards/
python3 -B quiet.py
tar -xzf guard-harness.tar.gz -C guards/build
tar -xzf head.tar.gz -C guards/build
(cd guards/build && crystal build --release --no-debug --threads 1 bench/streaming_token_cost.cr -o ../base)
tar -xzf candidate.tar.gz -C guards/build
(cd guards/build && crystal build --release --no-debug --threads 1 bench/streaming_token_cost.cr -o ../candidate)
(cd guards && taskset -c 0 python3 -B guard_dell.py > guard.log 2>&1)
