"""Validate, pair, and summarize the six builds on one streamed document."""
import hashlib,json,statistics as st,sys
from pathlib import Path
root=Path(sys.argv[1])
def read(f):return json.loads((root/f).read_text())
actual=read('result.json'); drain=read('gzip-drain.json')
assert actual['common_result']['bytes']==drain['result']
names=[r+'-'+g for r in ('release','head','candidate') for g in ('boehm','gcry')]
groups={n:[] for n in names}
for k in actual['accepted']:
    rec=read(k+'.json')
    value=dict(rec['result'])
    collector=value.pop('collector')
    assert collector==('boehm' if rec['name'].endswith('boehm') else 'gcry-0.40.0')
    assert actual['common_result']==value
    assert rec['gzip']['status']==rec['parser']['status']==rec['parser']['time_exit']==rec['gzip']['time_exit']==0
    assert rec['ac_end']=='1' and rec['sibling_idle']>=0.95 and rec['other_available']>=0.90
    groups[rec['name']].append(dict(round=int(k[1:k.index('-')]),wall=rec['wall_s'],cpu=rec['parser']['cpu_s'],gzip=rec['gzip']['cpu_s'],
                                    rss=rec['parser']['peak_rss_kib']/1024,throughput=value['bytes']/1048576/rec['wall_s']))
assert all([v['round'] for v in runs]==[1,2] for runs in groups.values())
stats={name:{k:dict(median=st.median(x[k] for x in runs),samples=[x[k] for x in runs]) for k in ('wall','cpu','gzip','rss','throughput')} for name,runs in groups.items()}
compare={}
for gc in ['boehm','gcry']:
    for other in ['head','release']:
        a,c=groups[other+'-'+gc],groups['candidate-'+gc]
        compare[other+'-'+gc]= {key:[(1-y[key]/x[key])*100 for x,y in zip(a,c)] for key in ['wall','cpu','rss']}
print(json.dumps(dict(stats=stats,improvement=compare,result=actual['common_result'],accepted=len(actual['accepted']),
                        retries=len(actual['retries']),drain_s=drain['wall_s']),indent=2))
