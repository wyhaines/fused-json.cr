import json,statistics as st,sys
from pathlib import Path
e=Path(sys.argv[1])
load=lambda name:json.loads((e/name).read_text())
a=load("aetna-summary.json"); u=load("uhc-summary.json")
env=load("aetna/environment.json"); other=load("uhc/input.json")
def percent(s,other,key):
    return st.median(s["improvement"][other][key])
def mid(s,build,key):return s["stats"][build][key]["median"]
def relative(s, other, key):
    v=percent(s, other, key)
    return f'{abs(v):.1f}% '+('lower' if v>=0 else 'higher')
def table(s):
    out=["| Parser | Collector | Pipeline wall (s) | Parser CPU (s) | Parser peak RSS (MiB) | Input MiB/s |",
         "| --- | --- | ---: | ---: | ---: | ---: |"]
    for label,rev in (("v0.4.0","release"),("Main at `7d48dc5`","head"),("Optimized","candidate")):
        for gc,name in (("boehm","Boehm 8.3.0"),("gcry","gcry 0.40.0")):
            v=rev+'-'+gc
            out.append(f'| {label} | {name} | {mid(s,v,"wall"):.2f} | {mid(s,v,"cpu"):.2f} | {mid(s,v,"rss"):.2f} | {mid(s,v,"throughput"):.1f} |')
    return out
out=['# Large-file streaming performance','',
    f'On the complete Aetna in-network file, the optimized parser used {percent(a,"head-boehm","cpu"):.1f}% less CPU time than `7d48dc5` with Boehm and {percent(a,"head-gcry","cpu"):.1f}% less with gcry. Including single-core gzip decompression, wall time fell {percent(a,"head-boehm","wall"):.1f}% and {percent(a,"head-gcry","wall"):.1f}%, respectively.',
    '', '## Aetna, whole file','',
    f'The input was `{env["source_file"]}`, SHA-256 `{env["compressed_sha256"]}`. The {env["stamp"][2]:,}-byte gzip expanded to {a["result"]["bytes"]:,} bytes. Every run found {a["result"]["negotiated_rate_keys"]:,} negotiated rate keys and returned checksum `{a["result"]["checksum"]}`.',
    '',*table(a),'',
    f'Against the released v0.4.0, the median paired reduction in wall time was {percent(a,"release-boehm","wall"):.1f}% with Boehm and {percent(a,"release-gcry","wall"):.1f}% with gcry. Across the full parse runs, gzip used {min(x["gzip"]["median"] for x in a["stats"].values()):.1f}–{max(x["gzip"]["median"] for x in a["stats"].values()):.1f} CPU seconds per build. The separate gzip-only pass took {a["drain_s"]:.2f} s.',
    '', '## UHC, first GiB','',
    f'A second input came from `{other["source"]}` ({other["source_compressed_bytes"]:,} bytes compressed). A streaming extractor copied its first GiB to the next comma outside a string, then closed the open containers and recompressed the sample with `gzip -1`. The resulting {u["result"]["bytes"]:,}-byte document was verified to EOF by all six builds (checksum `{u["result"]["checksum"]}`). The prefix contained {u["result"]["integers"]:,} integers and {u["result"]["negotiated_rate_keys"]:,} negotiated rate keys. These results describe the prefix.',
    '',*table(u),'',
    f'On this prefix, pipeline wall time relative to the previous main was {relative(u,"head-boehm","wall")} with Boehm and {relative(u,"head-gcry","wall")} with gcry. Parser CPU time was {relative(u,"head-boehm","cpu")} and {relative(u,"head-gcry","cpu")}, respectively.',
    '', '## What changed','',
    'A sampling profile of a 384 MiB Aetna prefix identified time spent constructing token slices, scanning strings, skipping whitespace, and updating container frames. On the prefix, median parser CPU time went from 3.42 s to 2.56 s across three fresh-process observations per build. The streaming reader now processes a plain ASCII string within the input buffer in one pass and copies the decoded value directly into its owned String. Strings with escapes or raw UTF-8 and strings split across refills use the general decoder.',
    '', 'The buffer index supplies the byte offset and the ASCII portion of the column. The parser adjusts the bases on refills, newlines and UTF-8 continuation bytes. It consumes recognized punctuation directly and changes an array’s frame state on the first element. These changes apply to the existing streaming API.',
    '', '## Measurement','',
    'The Dell XPS 15 9520 used its Core i9-12900HK, Crystal 1.22.3, and LLVM 22.1.3. Each release binary was built from the same absolute directory. The versions were v0.4.0 (`e06ba59`), main (`7d48dc5`), and main with the archived runtime patch. The gcry build used release 0.40.0 (`0fcca95`), `-Dgc_none`, and an early require of the collector.',
    '', 'The identical worker read every key and scalar with a 32 KiB buffer and `cache_keys: false`, retained counts and a checksum, and called `finish` at EOF. Each pipeline ran alone, with both `gzip -dc` and the parser pinned to logical CPU 2. GNU time measured user plus system CPU and maximum RSS of the parser separately from gzip. The table gives medians for two fresh processes per configuration. Percentages pair builds within each of the two reverse-order rounds.',
    '',f'The Aetna campaign accepted {a["accepted"]} measurements and recorded {a["retries"]} retries for host activity. The UHC prefix accepted {u["accepted"]} measurements with {u["retries"]} retries. Neither campaign wrote uncompressed JSON to disk.',
    '', '## Verification and controls','',
    'The candidate matched the previous implementation in 7,632 streaming comparisons over all 318 JSONTestSuite fixtures, including event traces, decoded values, error offsets, and line/column coordinates. In a standalone checkout, the default and scalar-scanner suites each passed 302 specs on Crystal 1.21.0 and 1.22.3. The portable-float and combined-fallback suites each passed 303. The development checkout also passed its nine additional experimental specs in each configuration. The gcry release build passed all 302 default specs, and the generated 4 GiB test verified positions beyond a 32-bit column.']
g=load('controls/observations.json')
keys=list(dict.fromkeys(x['receipt']['profile'] for x in g))
out+=['','A separate Dell run used the project’s smaller token benchmarks to check workloads with different characteristics. Ratios are candidate/baseline throughput across four paired rounds.','',
      '| Token fixture | Input | Consumer | Median throughput ratio | Range |','| --- | --- | --- | ---: | ---: |']
guard_summary=[]
for p in keys:
    base,candidate=([x['receipt'] for x in g if x['name']==n and x['receipt']['profile']==p] for n in ('base','candidate'))
    assert len(base)==len(candidate)==4
    vals=[y['iterations_per_second']/x['iterations_per_second'] for x,y in zip(base,candidate)]
    guard_summary.append((st.median(vals),min(vals),max(vals),p))
    out.append(f'| {p} | {base[0]["transport"]} | {base[0]["consumer"]} | {st.median(vals):.3f}× | {min(vals):.3f}–{max(vals):.3f} |')
med,lo,hi,profile=min(guard_summary)
if med<1:
    if profile=="raw-utf8":
        profile="raw UTF-8 in 13-byte reads"
    direction="All four pairs were slower." if hi<1 else "Individual pairs included results on both sides of the baseline."
    out+=['', f'The lowest median throughput ratio in these controls was {profile}, at {med:.3f}× ({100*(1-med):.1f}% lower throughput). {direction}']
out+=['','The archive contains individual process receipts, the unchanged worker, candidate patch, profiling and extraction tools, and reproduction instructions. [Benchmark evidence](benchmark-data/large-file-streaming-7d48dc5.tar.gz)']
print('\n'.join(out))
