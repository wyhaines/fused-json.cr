{% if flag?(:gc_none) %}
  require "./gcry/src/gcry"
{% end %}
require "./src/fused_json"

# A single reader traverses one complete document. The checksum depends on token
# order, decoded key and string bytes, and the numeric values returned to the caller.
class Traversal
  getter objects = 0_i64
  getter arrays = 0_i64
  getter keys = 0_i64
  getter strings = 0_i64
  getter integers = 0_i64
  getter floats = 0_i64
  getter literals = 0_i64
  getter rate_keys = 0_i64
  getter checksum = 0xcbf29ce484222325_u64

  private def mix(value : UInt64) : Nil
    @checksum = (@checksum ^ value) &* 0x100000001b3_u64
  end

  private def text(value : String) : Nil
    mix(value.bytesize.to_u64)
    value.each_byte { |b| mix(b.to_u64) }
  end

  def visit(pull : FusedJSON::StreamingPullParser) : Nil
    case pull.kind
    when .begin_object?
      @objects += 1
      mix(1_u64)
      pull.read_begin_object
      until pull.kind.end_object?
        key = pull.read_object_key
        @keys += 1
        @rate_keys += 1 if key == "negotiated_rate"
        text(key)
        visit(pull)
      end
      pull.read_end_object
      mix(2_u64)
    when .begin_array?
      @arrays += 1
      mix(3_u64)
      pull.read_begin_array
      until pull.kind.end_array?
        visit(pull)
      end
      pull.read_end_array
      mix(4_u64)
    when .string?
      @strings += 1
      mix(5_u64)
      text(pull.read_string)
    when .int?
      @integers += 1
      mix(6_u64)
      mix(pull.read_int.unsafe_as(UInt64))
    when .float?
      @floats += 1
      mix(7_u64)
      mix(pull.read_float.unsafe_as(UInt64))
    when .bool?
      @literals += 1
      mix(pull.read_bool ? 8_u64 : 9_u64)
    when .null?
      @literals += 1
      mix(10_u64)
      pull.read_null
    else
      raise "Unexpected event #{pull.kind}"
    end
  end
end

collector = {% if flag?(:gc_none) %} "gcry-" + Gcry::VERSION {% else %} "boehm" {% end %}
pull = FusedJSON::PullParser.new(STDIN, buffer_size: 32768, cache_keys: false)
stats = Traversal.new
stats.visit(pull)
pull.finish
puts({collector: collector, bytes: pull.byte_offset, objects: stats.objects, arrays: stats.arrays,
      keys: stats.keys, strings: stats.strings, integers: stats.integers, floats: stats.floats,
      literals: stats.literals, negotiated_rate_keys: stats.rate_keys, checksum: stats.checksum.to_s(16)}.to_json)
