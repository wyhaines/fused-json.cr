These exploratory token-benchmark runs took place on the local development
host, separately from the Dell. The second run checked whether passing an
already-read UTF-8 lead byte into the decoder improved a short-read test.
The results varied between runs, and this additional patch was left out of
the candidate. Use the Dell receipts for the published timings.
