import json,os,subprocess,statistics
from pathlib import Path
profiles=[
    ('plain-short','pull-materialize','io-memory','none',32768,0),
    ('plain-long','pull-skip','io-memory','none',32768,0),
    ('raw-utf8','pull-materialize','chunked-memory','none',13,0),
    ('escape-dense','dynamic-tree','io-memory','none',32768,0),
    ('key-repeated-plain','typed','io-memory','none',32768,1),
    ('floats','pull-materialize','io-memory','token',32768,0),
    ('integers','dynamic-tree','string','none',32768,0)]
cpu=min(os.sched_getaffinity(0))
obs=[]
profiles=[v for v in profiles if v[0] in {'raw-utf8','escape-dense','plain-short'}]
for i in range(5):
    for j, (p,c,t,l,chunk,cache) in enumerate(profiles):
        config=dict(FUSED_JSON_TOKEN_PROFILE=p,FUSED_JSON_TOKEN_CONSUMER=c,FUSED_JSON_TOKEN_TRANSPORT=t,
            FUSED_JSON_TOKEN_LIMITS=l,FUSED_JSON_TOKEN_CACHE_KEYS=str(cache),FUSED_JSON_TOKEN_CHUNK=str(chunk),
            FUSED_JSON_TOKEN_VALUES='512',FUSED_JSON_TOKEN_BYTES='128',FUSED_JSON_BENCH_WARMUP='1',FUSED_JSON_BENCH_TIME='1',
            FUSED_JSON_BENCH_ALLOCATIONS='3',FUSED_JSON_TOKEN_LATENCY_ITERATIONS='8',
            FUSED_JSON_BENCH_COMMIT='7d48dc577e8751bd8690d312a1aa5299c9e586cf',GC_NPROCS='1',GC_MARKERS='1')
        pair=[]
        for name in (['base','alt','candidate'] if (i+j)%2==0 else ['candidate','alt','base']):
            cmd=['taskset','-c',str(cpu),'./'+name]
            out=subprocess.check_output(cmd,env=dict(os.environ,**config),text=True)
            rec=json.loads(out.strip().splitlines()[-1])
            pair.append(rec)
            obs.append(dict(name=name,round=i+1,cpu=cpu,receipt=rec))
        assert all(pair[0][k]==pair[1][k] for k in ('expected_checksum','source_sha256','benchmark_source_sha256','benchmark_support_sha256'))
        Path('variant-observations.json').write_text(json.dumps(obs,indent=2)+'\n')
    print('round',i+1,flush=True)
for p,*_ in profiles:
    a,b=([s['receipt'] for s in obs if s['name']==n and s['receipt']['profile']==p] for n in ['base','candidate'])
    print(p,statistics.median(y['iterations_per_second']/x['iterations_per_second'] for x,y in zip(a,b)),flush=True)
